using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyRazorApp.Pages
{
    public class FormModel : PageModel
    {
        [BindProperty]
        public ContactFormModel ContactData { get; set; } = new ContactFormModel();  // Inicjalizacja modelu

        public bool Submitted { get; set; } = false;

        public void OnGet()
        {
            // Domy�lne �adowanie strony, tutaj wszystko jest gotowe do pracy
        }

        public IActionResult OnPost()
        {
            // Sprawdzanie, czy akcja to reset
            if (Request.Form["action"] == "reset")
            {
                ContactData = new ContactFormModel(); // Zresetowanie danych
                Submitted = false;
                return Page();
            }

            if (!ModelState.IsValid)
            {
                // Je�eli dane s� niepoprawne, zostaj� wy�wietlone b��dy walidacji
                return Page();
            }

            // Je�eli dane s� poprawne, formularz zosta� przes�any
            Submitted = true;
            return Page();
        }
    }
}
