using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MyRazorApp.Pages
{
    public class Calculate : PageModel
    {
        [BindProperty]
        public decimal Number1 { get; set; }

        [BindProperty]
        public decimal Number2 { get; set; }

        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            // Calculate the result
            var sum = Number1 + Number2;
            return Content(sum.ToString()); // Return the sum as a plain text response
        }
    }
}